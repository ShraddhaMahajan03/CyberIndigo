//
//  HomeViewController.swift
//  TaskCyberIndigo
//
//  Created by xtensibleimac on 07/11/20.
//  Copyright © 2020 Shraddha. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage


class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableview: UITableView!
    class var identifier: String { return String.className(self)}
    var userdataResponse: [User] = []
    var adResponse: [Ad] = []
    var userfNameArray = [String]()
    var userlNameArray = [String]()
    var userEmailArray = [String]()
    var userImgArray = [String]()
    var filteredUsers = [String]()
    var adCompanyArray = [String]()
    var adUrlArray = [String]()
    var adTextArray = [String]()
    var searchText : String?
    let searchController = UISearchController(searchResultsController: nil)
    var tapGesture = UITapGestureRecognizer()
    @IBOutlet weak var viewShowingAd: UIView!
    @IBOutlet weak var lblAdTitle: UILabel!
    @IBOutlet weak var lblAdDesc: UILabel!
    var adUrl : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.register(UINib.init(nibName: UserDataTableviewCell.identifier, bundle: nil), forCellReuseIdentifier: UserDataTableviewCell.identifier)
        self.tableview.delegate = self
        self.tableview.dataSource = self
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(HomeViewController.myviewTapped(_:)))
        tapGesture.numberOfTapsRequired = 1
        tapGesture.numberOfTouchesRequired = 1
        viewShowingAd.addGestureRecognizer(tapGesture)
        viewShowingAd.isUserInteractionEnabled = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.title = "Home"
        getResponse()
    }
    
    
    @objc func myviewTapped(_ sender: UITapGestureRecognizer) {
        if let url = NSURL(string: self.adUrl ?? ""){
            UIApplication.shared.openURL(url as URL)
        }
    }
    
    @IBAction func didTapLogoutButton(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: false)        
    }
    @IBAction func didTapSearchButton(_ sender: UIBarButtonItem) {
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.searchBar.keyboardType = UIKeyboardType.asciiCapable
        searchController.searchBar.delegate = self
        UIBarButtonItem.appearance(whenContainedInInstancesOf: [UISearchBar.self]).setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor(red: 26/255, green: 188/255, blue: 156/255, alpha: 1.0)], for: .normal)
        present(searchController, animated: true, completion: nil)
    }
    @IBAction func didTapLocationButton(_ sender: UIBarButtonItem) {
        let vc = UserInterface.mainModule.instantiateViewController(withIdentifier: LocationViewController.identifier) as! LocationViewController
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredUsers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: UserDataTableviewCell.identifier)as! UserDataTableviewCell
        cell.lblUaername.text = self.filteredUsers[indexPath.row] + " " + self.userlNameArray[indexPath.row]
        cell.lblEmail.text = self.userEmailArray[indexPath.row]
        
        if let urlString : String = userImgArray[indexPath.row]{
            cell.imgAvtar.sd_setImage(with: URL(string: urlString), placeholderImage: UIImage(named: ""), completed: { (image, error, cacheType, imageURL) in
                cell.imgAvtar.contentMode = .scaleAspectFill
            })
        }
        return cell
    }
    
}

extension HomeViewController : UISearchBarDelegate{
    func getResponse(){
        let req = Alamofire.request(URLConstant.baseURL_api + RequestName.users, method: .get, encoding: JSONEncoding.default).responseJSON { (response) in
            print("response : \(response)")
            switch response.result{
            case .success(let responsevalue):
                if let dict = responsevalue as? [String: Any]{
                    let model = UserDataModel(dictionary: dict)
                    for data in model.userData{
                        self.userfNameArray.append(data.first_name ?? "")
                        self.userlNameArray.append(data.last_name ?? "")
                        self.userEmailArray.append(data.email ?? "")
                        self.userImgArray.append(data.avatar ?? "")
                    }
                    self.filteredUsers = self.userfNameArray
                    
                    print("adUrl : \(String(describing: model.ad?.url))")
                    print("lblAdTitle : \(String(describing: model.ad?.company))")
                    print("lblAdDesc : \(String(describing: model.ad?.text))")
                    self.lblAdDesc.text = model.ad?.text
                    self.lblAdTitle.text = model.ad?.company
                    self.adUrl = model.ad?.url
                    self.tableview.reloadData()
                }
                
            case .failure(let err):
                print("\(err)")
                break
            }
        }
        print(req.debugDescription)
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.filteredUsers = []
        for name in self.userfNameArray{
            if self.searchController.searchBar.text == ""{
                self.filteredUsers = self.userfNameArray
            }else{
                if name.lowercased().contains(searchText.lowercased())
                {
                    self.filteredUsers.append(name)
                }
            }
            self.tableview.reloadData()
        }
    }
    
}

