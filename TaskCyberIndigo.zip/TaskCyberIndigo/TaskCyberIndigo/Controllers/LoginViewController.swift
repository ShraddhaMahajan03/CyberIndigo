//
//  LoginViewController.swift
//  TaskCyberIndigo
//
//  Created by xtensibleimac on 07/11/20.
//  Copyright © 2020 Shraddha. All rights reserved.
//

import UIKit
import Alamofire

class LoginViewController: UIViewController, UITextFieldDelegate {

    class var identifier: String { return String.className(self)}
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var txtEmail: FormTextField!
    @IBOutlet weak var txtPassword: FormTextField!
    var loginResponse: [LoginModel] = [LoginModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtEmail.delegate = self
        self.txtPassword.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        self.txtEmail.text = "eve.holt@reqres.in"
        self.txtPassword.text = "cityslicka"
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.txtEmail.resignFirstResponder()
        self.txtPassword.resignFirstResponder()
        return true
    }
    
    @IBAction func btnLoginTapped(_ sender: FormButton) {
        if txtEmail.text != "" && txtPassword.text != "" {
            if isValidEmail(email: txtEmail.text!) == true && isValidPassword(pass: txtPassword.text!) == true{
             getResponse(userName: self.txtEmail.text ?? "eve.holt@reqres.in", password: self.txtPassword.text ?? "cityslicka")
            }else{
                let alert = UIAlertController(title: "Alert", message: "Fill all of the fields with correct data.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
                self.present(alert, animated: true)
            }
        }else{
            let alert = UIAlertController(title: "Alert", message: "Fill all of the fields with correct data.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
       
    }
    
    public func isValidEmail(email: String) -> Bool {
         let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
         let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
         return emailTest.evaluate(with: email)
     }
     
    public func isValidPassword(pass: String) -> Bool {
         let passwordRegex = "^.{8,64}$"
         let passTest = NSPredicate(format:"SELF MATCHES %@", passwordRegex)
         return passTest.evaluate(with: pass)
     }
    
}

extension LoginViewController{
    func getResponse(userName:String, password:String){
        let dictParam = ["username":"eve.holt@reqres.in",
                                "password":"cityslicka",
                   ] as  Dictionary<String,String>
        let req = Alamofire.request(URLConstant.baseURL_api + RequestName.login, method: .post,parameters: dictParam, encoding: JSONEncoding.default).responseJSON { (response) in
               print("response : \(response)")
               switch response.result{
               case .success(let responsevalue):
                   if let dict = responsevalue as? [String: Any]{
                       let model = LoginModel(dictionary: dict)
                       self.loginResponse.append(model)
                    
                    let vc = UserInterface.mainModule.instantiateViewController(withIdentifier: HomeViewController.identifier) as! HomeViewController
                    self.navigationController?.navigationBar.isHidden = false
                    self.navigationController?.navigationItem.hidesBackButton = true
                    self.navigationController?.pushViewController(vc, animated: true)
                   }
               case .failure(let err):
                   print("\(err)")
                   break
               }
           }
           print(req.debugDescription)

       }
    
   
}
