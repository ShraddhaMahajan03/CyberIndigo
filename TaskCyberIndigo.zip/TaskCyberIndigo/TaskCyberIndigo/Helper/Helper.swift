//
//  Helper.swift
//  TaskCyberIndigo
//
//  Created by xtensibleimac on 07/11/20.
//  Copyright © 2020 Shraddha. All rights reserved.
//

import Foundation
import UIKit

extension String {
static func className(_ aClass: AnyClass) -> String {
    return NSStringFromClass(aClass).components(separatedBy: ".").last!
}
}

@IBDesignable

class FormTextField: UITextField {
    
    @IBInspectable var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
    }

    @IBInspectable var borderColor: UIColor? {
        didSet {
            layer.borderColor = borderColor?.cgColor
        }
    }

    @IBInspectable var borderWidth: CGFloat = 0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
}

class FormLabel: UILabel {
    @IBInspectable var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
    }

    @IBInspectable var borderColor: UIColor? {
        didSet {
            layer.borderColor = borderColor?.cgColor
        }
    }

    @IBInspectable var borderWidth: CGFloat = 0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable var topInset: CGFloat = 2.0
       @IBInspectable var bottomInset: CGFloat = 2.0
       @IBInspectable var leftInset: CGFloat = 2.0
       @IBInspectable var rightInset: CGFloat = 2.0

       override func drawText(in rect: CGRect) {
           let insets = UIEdgeInsets(top: topInset, left: leftInset, bottom: bottomInset, right: rightInset)
           super.drawText(in: rect.inset(by: insets))
       }

       override var intrinsicContentSize: CGSize {
           let size = super.intrinsicContentSize
           return CGSize(width: size.width + leftInset + rightInset,
                         height: size.height + topInset + bottomInset)
       }

       override var bounds: CGRect {
           didSet {
               preferredMaxLayoutWidth = bounds.width - (leftInset + rightInset)
           }
       }
}


class FormButton: UIButton {
    
    @IBInspectable var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
    }

    @IBInspectable var borderColor: UIColor? {
        didSet {
            layer.borderColor = borderColor?.cgColor
        }
    }

    @IBInspectable var borderWidth: CGFloat = 0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
  
        func createRoundedButton(backgroundColor:UIColor, title:String, CornerRadius:CGFloat, tintColor:UIColor) {
            self.setTitle(title, for: .normal)
            self.backgroundColor = backgroundColor
            self.tintColor = UIColor.white
            self.layer.cornerRadius = 4.0
            self.layer.shadowOpacity = 0.3
            self.layer.shadowColor =  UIColor.black.cgColor
            self.layer.shadowOffset = CGSize(width:0, height: 1)
            self.layer.masksToBounds = false
        }
        
        func createCornerButton(CornerRadius:CGFloat) {
            self.layer.cornerRadius = CornerRadius
            self.layer.masksToBounds = true
        }
        
   
}

extension UIView {
    
    func shadowView(backgroundColor:UIColor, CornerRadius:CGFloat, shadowOpacity: Float, shadowRadius: CGFloat){
    self.layer.cornerRadius = CornerRadius
        self.layer.shadowColor = backgroundColor.cgColor
    self.layer.shadowOffset = CGSize.zero
    self.layer.shadowOpacity = shadowOpacity
        self.layer.shadowRadius = shadowRadius
    self.layer.masksToBounds =  false
    }
    
    func createCircleView(backgroundColor:UIColor) {
        self.backgroundColor = backgroundColor
        self.tintColor = UIColor.white
        self.layer.cornerRadius = self.frame.size.width/2
        self.layer.shadowOpacity = 0.3
        self.layer.shadowColor =  UIColor.black.cgColor
        self.layer.shadowOffset = CGSize(width:0, height: 1)
        self.layer.masksToBounds = false
    }
    
    func createCardLayout() {
        self.backgroundColor = UIColor.white
        self.layer.cornerRadius = 4.0
        self.layer.shadowOpacity = 0.7
        self.layer.shadowColor =  UIColor.black.cgColor
        self.layer.shadowOffset = CGSize(width:0, height: 1)
        self.layer.masksToBounds = false
    }
    
    func createRoundedView() {
        self.layer.cornerRadius = 10.0
        self.layer.masksToBounds = true
    }
    
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        DispatchQueue.main.async {
            let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
            let mask = CAShapeLayer()
            mask.path = path.cgPath
            self.layer.mask = mask
        }
    }
}

