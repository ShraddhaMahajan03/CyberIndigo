//
//  Constants.swift
//  TaskCyberIndigo
//
//  Created by xtensibleimac on 07/11/20.
//  Copyright © 2020 Shraddha. All rights reserved.
//

import Foundation
import UIKit


struct URLConstant {
    static var baseURL_api = "https://reqres.in/api/"
    static var image_url = "https://s3.amazonaws.com/uifaces/faces/twitter/"
}
struct RequestName{
    static var login = "login"
    static var users = "users?page=2"
}
struct UserInterface  {
    static let mainModule = UIStoryboard(name: "Main", bundle: nil)
}
struct Messages {
    static let somethingwentwrongmessage = "Something Went Wrong"
    static let enter_name = "Please enter email"
    static let enter_mobile = "Please enter password"
}


