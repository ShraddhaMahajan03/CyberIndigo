//
//  UserDataTableviewCell.swift
//  TaskCyberIndigo
//
//  Created by xtensibleimac on 07/11/20.
//  Copyright © 2020 Shraddha. All rights reserved.
//

import UIKit

class UserDataTableviewCell: UITableViewCell {
    class var identifier: String { return String.className(self)}
    @IBOutlet weak var imgAvtar: UIImageView!
    @IBOutlet weak var lblUaername: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
