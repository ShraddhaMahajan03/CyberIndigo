//
//  LoginModel.swift
//  TaskCyberIndigo
//
//  Created by xtensibleimac on 07/11/20.
//  Copyright © 2020 Shraddha. All rights reserved.
//

import Foundation
class LoginModel {
    var token : String?
    convenience init(dictionary: [String:Any]) {
        self.init()
        token = dictionary["token"] as? String
    }
    
}
