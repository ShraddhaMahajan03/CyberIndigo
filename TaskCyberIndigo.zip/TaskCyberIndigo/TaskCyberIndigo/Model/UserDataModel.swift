//
//  UserDataModel.swift
//  TaskCyberIndigo
//
//  Created by xtensibleimac on 07/11/20.
//  Copyright © 2020 Shraddha. All rights reserved.
//

import Foundation
class UserDataModel {
        
       
    var userData = [User]()
    var ad : Ad?
        
        convenience init(dictionary: [String:Any]) {
            self.init()
            if let user_Data = dictionary["data"] as? [[String: Any]] {
                userData = user_Data.map({User(dictionary: $0)})
            }
            if let ad_Data = dictionary["ad"] as? [String: Any] {
                ad = Ad(dictionary: ad_Data)
            }
            
        }
        
    }

    class User {
        
        var id : Int?
        var email : String?
        var first_name : String?
        var last_name : String?
        var avatar : String?
        
        convenience init(dictionary: [String:Any]) {
            self.init()
            id = dictionary["id"] as? Int
            email = dictionary["email"] as? String
            first_name = dictionary["first_name"] as? String
            last_name = dictionary["last_name"] as? String
            avatar = dictionary["avatar"] as? String
           
        }
    }

class Ad {
       
       var company : String?
       var url : String?
       var text : String?
       
       convenience init(dictionary: [String:Any]) {
           self.init()
           company = dictionary["company"] as? String
           url = dictionary["url"] as? String
           text = dictionary["text"] as? String
       }
   }


